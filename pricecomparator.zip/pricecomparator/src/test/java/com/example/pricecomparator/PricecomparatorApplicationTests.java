package com.example.pricecomparator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PricecomparatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
