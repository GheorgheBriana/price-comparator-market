package com.example.pricecomparator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PricecomparatorApplication {

    public static void main(String[] args) {
        SpringApplication.run(PricecomparatorApplication.class, args);

    }
}
